package laborator4de;

import java.util.ArrayList;
import java.util.Iterator;

public class CandyBag{
    
    ArrayList<CandyBox> cutiiCiocolata=new ArrayList<>();
    cutiiCiocolata.add(new Lindt("Austria","cherry",20,5.4,19));
    cutiiCiocolata.add(new Lindt("Austria","apricot",20,5.4,19));
    cutiiCiocolata.add(new Lindt("Austria","strawberry",20,5.4,19));  
    cutiiCiocolata.add(new Bravelli("Italy","grape",6.7,8.7));
    cutiiCiocolata.add(new ChocAmor("France","caffee",5.5));
    cutiiCiocolata.add(new ChocAmor("France","vanilla",5.5));
    
}
