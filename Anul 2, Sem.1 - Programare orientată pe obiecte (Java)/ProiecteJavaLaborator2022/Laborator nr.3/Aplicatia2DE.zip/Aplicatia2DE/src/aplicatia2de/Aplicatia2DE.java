package aplicatia2de;

public class Aplicatia2DE {
    public static void main(String[] args) {
        
    }
    
}
