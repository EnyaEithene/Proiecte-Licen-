package aplicatia1;

public interface Plus {
    void plus(float nr);
}
