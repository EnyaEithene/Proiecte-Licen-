package aplicatia1;

public interface Div {
    void div(float nr);
}
