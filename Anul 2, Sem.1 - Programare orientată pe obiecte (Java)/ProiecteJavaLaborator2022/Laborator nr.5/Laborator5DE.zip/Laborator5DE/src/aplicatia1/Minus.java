package aplicatia1;

public interface Minus {
    void minus(float nr);
}
