package aplicatia1;

public interface Mult {
    void mult(float nr);
}
