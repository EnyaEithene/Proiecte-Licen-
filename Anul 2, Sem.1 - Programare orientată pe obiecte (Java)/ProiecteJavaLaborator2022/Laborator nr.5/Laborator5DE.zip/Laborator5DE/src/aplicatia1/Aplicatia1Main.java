package aplicatia1;

public class Aplicatia1Main {
    public static void main(String[] args) {
        
    }
    
}
