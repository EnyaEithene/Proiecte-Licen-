package aplicatia3;

public interface Offer {
    int getDiscount(Car car,double nr);
}
